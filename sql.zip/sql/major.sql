INSERT INTO INSTANCE.MAJOR
    (ABBREVIATION, NAME, FACULTY)
VALUES
('SWB', 'Softwaretechnik und Medieninformatik', 'IT'),
('SWT', 'Softwaretechnik', 'IT'),
('SWM', 'Medieninformatik', 'IT'),
('TIB', 'Technische Informatik', 'IT'),
('KTB', 'Kommunikationstechnik', 'IT'),
('WKB', 'Wirtschaftsinformatik', 'IT'),
('ASM', 'Angewandte Informatik', 'IT');

