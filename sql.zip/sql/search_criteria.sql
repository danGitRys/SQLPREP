INSERT INTO instance.SEARCH_CRITERIA (semester_start, major, semester)
VALUES ('SS15', 'SWB', 6);
