-- trigger for PROFESSOR table
CREATE OR REPLACE TRIGGER check_existing_lecturer
BEFORE INSERT ON instance.professor
REFERENCING NEW AS NEW_ROW
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM instance.lecturer WHERE teacher_id = NEW_ROW.teacher_id) THEN
        SIGNAL SQLSTATE '45000';
    END IF;
END;

-- trigger for LECTURER table
CREATE OR REPLACE TRIGGER check_existing_professor
BEFORE INSERT ON instance.lecturer
REFERENCING NEW AS NEW_ROW
FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM instance.professor WHERE teacher_id = NEW_ROW.teacher_id) THEN
        SIGNAL SQLSTATE '45000';
    END IF;
END;
