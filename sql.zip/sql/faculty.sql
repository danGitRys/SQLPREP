INSERT INTO INSTANCE.FACULTY
    (ABBREVIATION, NAME)
VALUES
('IT', 'Informatik und Informationstechnik'),
('G', 'to do'),
('IFS', 'to do'),
('GS', 'to do'),
('SP', 'Soziale Arbeit Bildung und Pflege'),
('WT', 'Wirtschaft und Technik');
