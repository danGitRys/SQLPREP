-- stored procedure for PROFESSOR
CREATE OR REPLACE PROCEDURE calculate_credited_teacher_hours(
    IN semester_start VARCHAR(10)
)
LANGUAGE SQL
BEGIN
    DECLARE total_credited_teacher_hours INT DEFAULT 0;
    DECLARE v_teacher_id INT;
    DECLARE done INT DEFAULT 0;

    -- go through all active professors
    DECLARE cur CURSOR FOR
        SELECT teacher_id
        FROM INSTANCE.PROFESSOR
        WHERE is_active = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN cur;
    FETCH cur INTO v_teacher_id;

    -- loop through 
    WHILE done = 0 DO
        SET total_credited_teacher_hours = 0;

        -- calculate workload
        SELECT COALESCE(SUM(credited_teacher_hours),0)
        INTO total_credited_teacher_hours
        FROM INSTANCE.COURSE
        WHERE teacher = v_teacher_id
          AND course_start = semester_start;

        -- subtract compulsory hours
        SET total_credited_teacher_hours = total_credited_teacher_hours - 18;

        -- update credit hour account
        UPDATE INSTANCE.PROFESSOR
        SET credit_hour_account = credit_hour_account + total_credited_teacher_hours
        WHERE teacher_id = v_teacher_id;

        FETCH cur INTO v_teacher_id;
    END WHILE;
    CLOSE cur;
END;

-- trigger to update PROFESSOR
CREATE OR REPLACE TRIGGER update_credit_hour_account
AFTER UPDATE OF semester_start ON INSTANCE.SEARCH_CRITERIA
REFERENCING OLD AS OLD_ROW NEW AS NEW_ROW
FOR EACH ROW
BEGIN
    -- only if there is a difference
    IF OLD_ROW.semester_start <> NEW_ROW.semester_start THEN
        -- call sp
        CALL calculate_credited_teacher_hours(OLD_ROW.semester_start);
    END IF;
END;

